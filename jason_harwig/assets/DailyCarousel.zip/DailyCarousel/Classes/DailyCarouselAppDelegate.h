//
//  DailyCarouselAppDelegate.h
//  DailyCarousel
//
//  Created by Jason Harwig on 2/5/11.
//  Copyright 2011 Near Infinity Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DailyCarouselViewController;

@interface DailyCarouselAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    DailyCarouselViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet DailyCarouselViewController *viewController;

@end

