
@interface DailyCarouselViewController : UIViewController {

}

@end

