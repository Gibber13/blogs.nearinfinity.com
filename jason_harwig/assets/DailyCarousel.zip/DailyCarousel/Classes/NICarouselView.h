//
//  NICarouselView.h
//  DailyCarousel
//
//  Created by Jason Harwig on 2/5/11.
//  Copyright 2011 Near Infinity Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface NICarouselView : UIView {
    float startingAngle;
}

- (IBAction)setNumberOfItems:(id)slider;
- (IBAction)setXRadius:(id)slider;
- (IBAction)setZRadius:(id)slider;
@end
