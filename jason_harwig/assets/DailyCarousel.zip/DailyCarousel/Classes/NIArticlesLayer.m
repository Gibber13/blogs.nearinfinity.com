//
//  NICArticlesLayer.m
//  DailyCarousel
//
//  Created by Jason Harwig on 2/5/11.
//  Copyright 2011 Near Infinity Corporation. All rights reserved.
//

#import "NIArticlesLayer.h"
#import "NIArticleLayer.h"

static inline float easeOutCubic(float pos){
    return powf(pos - 1, 3.0) + 1;
}


@implementation NIArticlesLayer
@synthesize radius,
            items,
            angle;

+ (BOOL)needsDisplayForKey:(NSString *)key {
    if ([key isEqualToString:@"angle"])
        return YES;
    
    return [super needsDisplayForKey:key];
}

- (void)addArticle:(UIColor *)color {
    CGRect bounds = CGRectMake(0,0,200,275);
    NIArticleLayer *article = [NIArticleLayer layer];
    article.bounds = bounds;  
    [transformLayer addSublayer:article];
    [article setNeedsDisplay];    
    
    NSString *filename = [NSString stringWithFormat:@"IMG_00%i", (imageNumber+39)];
    UIImage *image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:filename ofType:@"PNG"]];
    article.contents = (id) image.CGImage;
    article.contentsGravity = kCAGravityResizeAspect;

    // Cache reflection image
    UIGraphicsBeginImageContext(bounds.size);
    CGContextClipToMask(UIGraphicsGetCurrentContext(), bounds, [UIImage imageNamed:@"mask"].CGImage);
    [image drawInRect:bounds];
    UIImage *reflectionImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();    
    
    CALayer *reflection = article.reflection = [CALayer layer];
    reflection.anchorPoint = CGPointMake(0.5, 0);        
    reflection.bounds = bounds;
    [transformLayer addSublayer:reflection];
    [reflection setNeedsDisplay];
    reflection.contents = (id)reflectionImage.CGImage;    
    reflection.contentsGravity = self.contentsGravity;
        
    imageNumber = (imageNumber + 1) % 15;
        
    self.items = [items arrayByAddingObject:article];
}

- (id) init
{
    self = [super init];
    if (self != nil) {
        angle = M_PI_2;
        radius = CGPointMake(1042, 2000);   
        imageNumber = 0;
                
        CATransform3D t = CATransform3DIdentity;
        t.m34 = 1.0 / -400;    
        self.sublayerTransform = t;    
        
        transformLayer = [CATransformLayer layer];        
        [self addSublayer:transformLayer];                        
        [self setItemCount:30];
        [self setNeedsDisplay];
    }
    return self;
}

- (void) dealloc
{
    [items release];
    [super dealloc];
}

- (void)setAngle:(float)a {
    [displayLink invalidate];
    displayLink = nil;
    angle = a;
    [self setNeedsLayout];
}
- (void)setAngle:(float)a animated:(BOOL)animate {
    [displayLink invalidate];

    if (animate) {
        startTimestamp = CACurrentMediaTime();
        startAngle = angle;
        endAngle = a;
        displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(animate:)];
        [displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    } else {
        self.angle = a;
    }
}
- (void)stopAnimation {
    [displayLink invalidate];
    displayLink = nil;
}

- (void)animate:(CADisplayLink *)link {
    float dt = (link.timestamp - startTimestamp) / 1.0;
    if (dt > 1.0) {
        [displayLink invalidate];
        displayLink = nil;
        return;
    }
        
    angle = startAngle + easeOutCubic(dt) * (endAngle - startAngle);
    [self setNeedsLayout];
}


- (void)setItemCount:(int)count {
    srandom(time(NULL));
    transformLayer.sublayers = nil;
    self.items = [NSArray array];
    imageNumber = 0;
    for (int i = 0; i < count; i++) {
        float hue = (random() % 100) / 100.0;
        float saturation = (random() % 50) / 100.0 + 0.25;
        [self addArticle:[UIColor colorWithHue:hue saturation:saturation brightness:0.5 alpha:1.0]];            
    }    

    [self setNeedsDisplay];
    [self setNeedsLayout];
}

- (void)layoutSublayers {
    [super layoutSublayers];
    
    transformLayer.frame = self.bounds;
    
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    
    float angleDelta = 2 * M_PI / [items count];
    float a = angle;
    
    for (NIArticleLayer *l in items) {
        l.position = transformLayer.position;  
        CGPoint p = transformLayer.position;
        p.y += l.reflection.bounds.size.height / 2.0;
        l.reflection.position = p;
        
        CATransform3D translation = CATransform3DMakeTranslation(cosf(a)*(radius.x), l.bounds.size.height * -0.1, (sinf(a)*radius.y) - radius.y*0.9);
        //float coverflowAngle = a + M_PI_2;
        float dailyAngle = (M_PI_2 - a);
        CATransform3D rotation = CATransform3DMakeRotation(dailyAngle, 0, 1.0, 0);
        CATransform3D t = CATransform3DConcat(rotation, translation);
        l.transform = t;
                
        CATransform3D rotate = CATransform3DMakeRotation(0, 1.0, 0, 0);
        CATransform3D flip = CATransform3DConcat( CATransform3DMakeScale(1.0, -1.0, 1.0), CATransform3DMakeTranslation(0, l.reflection.bounds.size.height, 0));
        CATransform3D reflection = CATransform3DConcat(flip, rotate);
        
        l.reflection.transform = CATransform3DConcat(reflection, t);

        float pos = fmodf(fabsf(dailyAngle), 2 * M_PI);
        BOOL show = (pos < M_PI_4 || pos > 2 * M_PI - M_PI_4 );
        l.hidden = l.reflection.hidden = !show;
        
        a += angleDelta;
    }
    [CATransaction commit];    
}


@end
