//
//  NICArticleLayer.m
//  DailyCarousel
//
//  Created by Jason Harwig on 2/5/11.
//  Copyright 2011 Near Infinity Corporation. All rights reserved.
//

#import "NIArticleLayer.h"
#import <QuartzCore/QuartzCore.h>

@implementation NIArticleLayer

@synthesize reflection;

@end
