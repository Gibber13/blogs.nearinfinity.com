//
//  DailyCarouselViewController.m
//  DailyCarousel
//
//  Created by Jason Harwig on 2/5/11.
//  Copyright 2011 Near Infinity Corporation. All rights reserved.
//

#import "DailyCarouselViewController.h"

@implementation DailyCarouselViewController

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

@end
