
@interface NIArticleLayer : CALayer {
    CALayer *reflection;
}

@property (nonatomic, retain) CALayer *reflection;

@end
