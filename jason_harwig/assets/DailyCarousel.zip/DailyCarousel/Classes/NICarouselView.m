//
//  NICarouselView.m
//  DailyCarousel
//
//  Created by Jason Harwig on 2/5/11.
//  Copyright 2011 Near Infinity Corporation. All rights reserved.
//

#import "NICarouselView.h"
#import "NIArticlesLayer.h"

@implementation NICarouselView

+ (Class)layerClass {
    return [NIArticlesLayer class];
}

- (void)commonInit {    
    UIGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pan:)];
    [self addGestureRecognizer:pan];            
    [pan release];
    self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"background.PNG"]];
}

- (id)initWithCoder:(NSCoder *)aCoder {
    self = [super initWithCoder:aCoder];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    NIArticlesLayer *l = (NIArticlesLayer *) self.layer;    
    [l stopAnimation];
}

- (void)pan:(UIPanGestureRecognizer *)pan {
    CGPoint translation = [pan translationInView:self];                    
    NIArticlesLayer *l = (NIArticlesLayer *) self.layer;    
    
    float circumference = l.radius.x * 2 * M_PI;
    
    if (pan.state == UIGestureRecognizerStateBegan) {
        startingAngle = l.angle;
    } else if (pan.state == UIGestureRecognizerStateEnded) {        

        CGPoint velocity = [pan velocityInView:self];        
        float damping = 0.2;
        float endAngle = (l.angle - ((velocity.x * damping / circumference) * (2*M_PI)));
        
        [l setAngle:endAngle animated:YES];
    } else if (pan.state == UIGestureRecognizerStateChanged) {                
        float damping = 0.7;
        
        l.angle = startingAngle - ((translation.x * damping / circumference) * (2*M_PI));          
    }
}


- (IBAction)setNumberOfItems:(UISlider *)slider {
    NIArticlesLayer *l = (NIArticlesLayer *) self.layer;
    NSLog(@"number of items = %f", slider.value);
    [l setItemCount:(int)[slider value]];
}
- (IBAction)setXRadius:(UISlider *)slider {
    NIArticlesLayer *l = (NIArticlesLayer *) self.layer;

    CGPoint nr = l.radius;
    nr.x = slider.value;
    NSLog(@"x radius %f", slider.value);    
    l.radius = nr;
    [l setNeedsLayout];    
}
- (IBAction)setZRadius:(UISlider *)slider {
    NIArticlesLayer *l = (NIArticlesLayer *) self.layer;
    
    CGPoint nr = l.radius;
    nr.y = slider.value;
    NSLog(@"z radius %f", slider.value);        
    l.radius = nr;    
    [l setNeedsLayout];        
}


@end
