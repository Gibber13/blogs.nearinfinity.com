
@interface NIArticlesLayer : CALayer {
    CATransformLayer *transformLayer;
    CALayer *floor;
    NSArray *items;
    float angle;
    CGPoint radius;
    float startAngle;
    float endAngle;
    CFTimeInterval startTimestamp;
    CADisplayLink *displayLink;
    
    int imageNumber;
}

@property (nonatomic, assign) float angle;
@property (nonatomic, assign) CGPoint radius;
@property (nonatomic, copy) NSArray *items;

- (void)stopAnimation;
- (void)setAngle:(float)a animated:(BOOL)animated;
- (void)setItemCount:(int)count;
@end
